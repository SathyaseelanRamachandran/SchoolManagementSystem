<?php

    //Sathya ram
	$currDir=dirname(__FILE__);
	include("$currDir/defaultLang.php");
	include("$currDir/language.php");
	include("$currDir/lib.php");
	@include("$currDir/hooks/academic_year.php");
	include("$currDir/academic_year_dml.php");

	// mm: can the current member access this page?
	$perm=getTablePermissions('academic_year');
	if(!$perm[0]){
		echo error_message($Translation['tableAccessDenied'], false);
		echo '<script>setTimeout("window.location=\'index.php?signOut=1\'", 2000);</script>';
		exit;
	}

	$x = new DataList;
	$x->TableName = "academic_year";

	// Fields that can be displayed in the table view
	$x->QueryFieldsTV = array(   
		"`academic_year`.`id`" => "id",
		"`academic_year`.`name`" => "name"
	);
	// mapping incoming sort by requests to actual query fields
	$x->SortFields = array(   
		1 => '`academic_year`.`id`',
		2 => 2
	);

	// Fields that can be displayed in the csv file
	$x->QueryFieldsCSV = array(   
		"`academic_year`.`id`" => "id",
		"`academic_year`.`name`" => "name"
	);
	// Fields that can be filtered
	$x->QueryFieldsFilters = array(   
		"`academic_year`.`id`" => "ID",
		"`academic_year`.`name`" => "Name"
	);

	// Fields that can be quick searched
	$x->QueryFieldsQS = array(   
		"`academic_year`.`id`" => "id",
		"`academic_year`.`name`" => "name"
	);

	// Lookup fields that can be used as filterers
	$x->filterers = array();

	$x->QueryFrom = "`academic_year` ";
	$x->QueryWhere = '';
	$x->QueryOrder = '';

	$x->AllowSelection = 1;
	$x->HideTableView = ($perm[2]==0 ? 1 : 0);
	$x->AllowDelete = $perm[4];
	$x->AllowMassDelete = false;
	$x->AllowInsert = $perm[1];
	$x->AllowUpdate = $perm[3];
	$x->SeparateDV = 1;
	$x->AllowDeleteOfParents = 0;
	$x->AllowFilters = 1;
	$x->AllowSavingFilters = 0;
	$x->AllowSorting = 1;
	$x->AllowNavigation = 1;
	$x->AllowPrinting = 1;
	$x->AllowCSV = 1;
	$x->RecordsPerPage = 10;
	$x->QuickSearch = 1;
	$x->QuickSearchText = $Translation["quick search"];
	$x->ScriptFileName = "academic_year_view.php";
	$x->RedirectAfterInsert = "academic_year_view.php?SelectedID=#ID#";
	$x->TableTitle = "Academic year";
	$x->TableIcon = "resources/table_icons/check_box.png";
	$x->PrimaryKey = "`academic_year`.`id`";

	$x->ColWidth   = array(  150);
	$x->ColCaption = array("Name");
	$x->ColFieldName = array('name');
	$x->ColNumber  = array(2);

	// template paths below are based on the app main directory
	$x->Template = 'templates/academic_year_templateTV.html';
	$x->SelectedTemplate = 'templates/academic_year_templateTVS.html';
	$x->TemplateDV = 'templates/academic_year_templateDV.html';
	$x->TemplateDVP = 'templates/academic_year_templateDVP.html';

	$x->ShowTableHeader = 1;
	$x->ShowRecordSlots = 0;
	$x->TVClasses = "";
	$x->DVClasses = "";
	$x->HighlightColor = '#FFF0C2';

	// mm: build the query based on current member's permissions
	$DisplayRecords = $_REQUEST['DisplayRecords'];
	if(!in_array($DisplayRecords, array('user', 'group'))){ $DisplayRecords = 'all'; }
	if($perm[2]==1 || ($perm[2]>1 && $DisplayRecords=='user' && !$_REQUEST['NoFilter_x'])){ // view owner only
		$x->QueryFrom.=', membership_userrecords';
		$x->QueryWhere="where `academic_year`.`id`=membership_userrecords.pkValue and membership_userrecords.tableName='academic_year' and lcase(membership_userrecords.memberID)='".getLoggedMemberID()."'";
	}elseif($perm[2]==2 || ($perm[2]>2 && $DisplayRecords=='group' && !$_REQUEST['NoFilter_x'])){ // view group only
		$x->QueryFrom.=', membership_userrecords';
		$x->QueryWhere="where `academic_year`.`id`=membership_userrecords.pkValue and membership_userrecords.tableName='academic_year' and membership_userrecords.groupID='".getLoggedGroupID()."'";
	}elseif($perm[2]==3){ // view all
		// no further action
	}elseif($perm[2]==0){ // view none
		$x->QueryFields = array("Not enough permissions" => "NEP");
		$x->QueryFrom = '`academic_year`';
		$x->QueryWhere = '';
		$x->DefaultSortField = '';
	}
	// hook: academic_year_init
	$render=TRUE;
	if(function_exists('academic_year_init')){
		$args=array();
		$render=academic_year_init($x, getMemberInfo(), $args);
	}

	if($render) $x->Render();

	// hook: academic_year_header
	$headerCode='';
	if(function_exists('academic_year_header')){
		$args=array();
		$headerCode=academic_year_header($x->ContentType, getMemberInfo(), $args);
	}  
	if(!$headerCode){
		include_once("Sathya Ram"); 
	}else{
		ob_start(); include_once("Sathya Ram"); $dHeader=ob_get_contents(); ob_end_clean();
		echo str_replace('<%%HEADER%%>', $dHeader, $headerCode);
	}

	echo $x->HTML;
	// hook: academic_year_footer
	$footerCode='';
	if(function_exists('academic_year_footer')){
		$args=array();
		$footerCode=academic_year_footer($x->ContentType, getMemberInfo(), $args);
	}  
	if(!$footerCode){
		include_once("Sathya Ram"); 
	}else{
		ob_start(); include_once("Sathya Ram"); $dFooter=ob_get_contents(); ob_end_clean();
		echo str_replace('<%%FOOTER%%>', $dFooter, $footerCode);
	}
?>